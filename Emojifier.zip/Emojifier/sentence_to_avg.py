# GRADED FUNCTION: sentence_to_avg

def sentence_to_avg(sentence, word_to_vec_map):
    """
    Converts a sentence (string) into a list of words (strings). Extracts the GloVe representation of each word
    and averages its value into a single vector encoding the meaning of the sentence.

    Arguments:
    sentence -- string, one training example from X
    word_to_vec_map -- dictionary mapping every word in a vocabulary into its 50-dimensional vector representation

    Returns:
    avg -- average vector encoding information about the sentence, numpy-array of shape (50,)
    """

    ### START CODE HERE ###
    # Step 1: Split sentence into list of lower case words
    words = sentence.lower().split()

    # Initialize the average word vector, should have the same shape as your word vectors.
    avg = np.zeros((50,))

    # Step 2: average the word vectors. You can loop over the words in the list "words".
    for w in words:
        avg += word_to_vec_map[w]
    avg = avg/len(words)

    ### END CODE HERE ###

    return avg

avg = sentence_to_avg("Morrocan couscous is my favorite dish", word_to_vec_map)
print("avg = ", avg)

# avg =  [-0.008005    0.56370833 -0.50427333  0.258865    0.55131103  0.03104983
#  -0.21013718  0.16893933 -0.09590267  0.141784   -0.15708967  0.18525867
#   0.6495785   0.38371117  0.21102167  0.11301667  0.02613967  0.26037767
#   0.05820667 -0.01578167 -0.12078833 -0.02471267  0.4128455   0.5152061
#   0.38756167 -0.898661   -0.535145    0.33501167  0.68806933 -0.2156265
#   1.797155    0.10476933 -0.36775333  0.750785    0.10282583  0.348925
#  -0.27262833  0.66768    -0.10706167 -0.283635    0.59580117  0.28747333
#  -0.3366635   0.23393817  0.34349183  0.178405    0.1166155  -0.076433
#   0.1445417   0.09808667]